# myNixos: Niri + MangoWC + DankMaterialShell

## Fix: niri bind properties (allow-when-locked, repeat, cooldown-ms, allow-inhibiting)

The build failed with `only one action is allowed per keybind` — caused
by binds like `"XF86MonBrightnessUp".allow-when-locked = true;` next to
`"XF86MonBrightnessUp".spawn = [...];`. Nix's dot-path attrset merging
collapses those into one flat attrset (`{ allow-when-locked = true;
spawn = [...]; }`), and `wrapper-modules`' niri module reads every key
in a bind's value as a candidate *action* — `allow-when-locked` isn't
one of its ~133 known actions, hence the parse error.

The real schema (confirmed from the module's own generated docs) nests
properties separately from the action, using the function form:

```nix
"XF86MonBrightnessUp" = _: {
  props.allow-when-locked = true;
  content.spawn = [ "brightnessctl" "--class=backlight" "set" "+10%" ];
};
```

Every bind in `niri.nix` carrying `allow-when-locked`, `repeat`,
`cooldown-ms`, or `allow-inhibiting` — the volume/media/brightness
keys, `Mod+O`, `Mod+Q`, the wheel-scroll workspace binds, and
`Mod+Escape` — now uses this form. Plain binds with no extra
properties (`"Mod+N".spawn = [...]`, etc.) are unaffected; that
shorthand was always correct.

## Fix: Helium browser

The bare `helium-browser` package attribute doesn't exist on nixpkgs —
that was a bad bet in an earlier round (the official nixpkgs PR is
still pending upstream). Replaced with a real flake:
`oxcl/nix-flake-helium-browser`, which repackages Helium's official
`.deb` releases the same way nixpkgs itself packages Brave/Vivaldi, and
ships an actual NixOS module. `configuration.nix` now imports
`inputs.helium-browser.nixosModules.default` and uses
`programs.helium.enable = true;` (with `--ozone-platform-hint=auto`
for native Wayland) instead of a plain package reference.

## This round's changes

- **Bluetooth.** `hardware.bluetooth.enable = true;` +
  `powerOnBoot = true;` in `configuration.nix`. No separate GUI agent
  package (`blueman`, etc.) added — DMS's own bluetooth widget talks to
  `bluez` directly, same reasoning as not adding a second polkit agent.
- **MangoWC is now actually on**, not just toggleable —
  `my.compositors.mango.enable = true;` in `configuration.nix`. Both
  Niri and MangoWC are installed and available as sessions for `izo`;
  see the "unverified" note below on whether the greeter shows a live
  picker between them.
- **GRUB theme** — still the vendored `stylish` theme
  (`boot.loader.grub.theme = ./grub-theme/stylish;`), no path change
  needed. Content updated to match the newly supplied version, which
  turned out identical byte-for-byte except one line in `theme.txt`:
  `boot_menu`'s `left` moved from `30%` to `15%`, shifting the boot
  menu box closer to the screen's left edge.
- **"Open in Ghostty" in Nautilus's right-click menu** — new
  `modules/features/nautilus-terminal.nix` enables nixpkgs' native
  `programs.nautilus-open-any-terminal` module with
  `terminal = "ghostty"`. That module already handles everything a
  GNOME-less setup like this one needs (installs `nautilus-python` +
  the extension, points `NAUTILUS_4_EXTENSION_DIR` since
  `services.desktopManager.gnome` isn't enabled here, links the
  extensions path, writes the terminal choice into a locked system
  dconf profile) — no manual wiring needed on top. Ghostty specifically
  needs one more piece the extension's own README flags: with
  Ghostty's default GTK single-instance mode, a second
  `--working-directory=...` invocation gets silently forwarded to
  whatever Ghostty window is already open and the flag gets ignored —
  so the context-menu entry would open in the wrong folder once any
  Ghostty window already exists. The same file also adds a
  `~/.config/ghostty/config` (home-manager) setting
  `gtk-single-instance = false` to fix that.
- **No more fastfetch autorun on every new terminal** —
  `modules/features/fish.nix`'s `fish_greeting` function used to run
  `fastfetch` on every interactive shell start; it's now set to empty
  (not just deleted, so Fish doesn't fall back to printing its own
  stock "Welcome to fish" banner instead). `fastfetch` itself is still
  installed (`environment.systemPackages`, `configuration.nix`) — it
  just doesn't run automatically anymore.
- **Infinity Glass icon theme**, set as default for `izo`, replacing
  Crystal Remix. Also not in nixpkgs, so `modules/features/icon-theme.nix`
  packages it directly from `github:rogts/infinity-icon-theme`. That
  repo has no tags/releases at all (confirmed against its actual
  Releases page), so it's pinned to a commit
  (`55370c3a9076d0793c1157f6e667d79bd6f9f4b8`, the tip of `main` as of
  this change) instead. It ships two variants at its repo root,
  `infinity` (light) and `infinity-dark` (dark) — both are installed,
  and `gtk.iconTheme.name` defaults to `"infinity-dark"` to match the
  dark-by-default change below. `infinity-dark`'s own `index.theme`
  declares `Inherits=breeze,hicolor` (it's a partial Breeze re-skin,
  not a from-scratch set), so `kdePackages.breeze-icons` is bundled
  alongside it via `symlinkJoin` for fallback icons — without it,
  icons the theme doesn't override resolve to nothing, which is a
  real reported failure mode for this theme (GTK apps like Lutris
  SIGABRT-ing on missing `scalable/status/*.svg`, per the KDE Store
  reviews for it). The fetcher hash is still `lib.fakeHash` — first
  rebuild will fail and print the real one to paste in, the same
  one-time step Crystal Remix needed.
- **Dark theme by default** — new `modules/features/dark-theme.nix`
  sets `color-scheme = "prefer-dark"` via dconf (the portal-standard
  hint GTK4/libadwaita/Qt6 apps read) and
  `gtk-application-prefer-dark-theme` for GTK3/GTK4 directly, so the
  system starts dark independent of whatever DMS's matugen-driven
  dynamic theming (`enableDynamicTheming`, `dms.nix`) later derives
  from the wallpaper. DMS's own light/dark toggle (`Mod+Comma`) is
  separate runtime UI state it stores itself — not a NixOS/home-manager
  option — so it isn't covered here; flip it once by hand if DMS's
  own shell still comes up light on first login.
- **MangoWC not showing DMS after login, fixed** — Mango imports the
  session environment into systemd on its own
  (`dbus-update-activation-environment` /
  `systemctl --user import-environment`, confirmed in mango's own
  `src/mango.c`), but never runs
  `systemctl --user start graphical-session.target`. Since `dms.service`
  (`dms.nix`) is `wantedBy = ["graphical-session.target"]`, it never
  fired under Mango — the compositor itself came up fine, just with no
  bar/launcher/polkit-agent, which is what "not working after
  selecting and authenticating in dms-greeter" actually was. Niri
  starts that target itself, which is why the same setup "just
  worked" there. `modules/features/mango-keybinds.nix` now adds
  `exec-once=systemctl --user start graphical-session.target` to
  close that gap. Also fixed nearby: `dms-greeter.nix`'s comment
  guessed the Mango session id as `"mangowc"` — it's actually
  `"mango"`, confirmed from upstream's `assets/mango.desktop`
  (`DesktopNames=mango;wlroots`).

## This round's still-unverified items

- Whether DankGreeter now shows both Niri and MangoWC as a live pick,
  now that MangoWC is actually enabled — this is the point where you
  can finally check it. See `dms-greeter.nix` for the fallback if not.

## Previous rounds

### 1. Home Manager now actually manages izo

`modules/features/home-manager.nix` wires in
`inputs.home-manager.nixosModules.home-manager` and gives `izo` a real
profile — not a placeholder. **Fish and Starship moved from plain
NixOS modules to home-manager modules** (`flake.homeModules.fishShell`
/ `flake.homeModules.starshipPrompt` in `fish.nix`/`starship.nix`),
which is a genuine improvement, not just a relocation: Home Manager's
`programs.fish` has a real `functions` option, so `mkcd` and
`fish_greeting` are now proper Fish functions instead of text pasted
into `interactiveShellInit`.

Niri, DMS, and the greeter **stay plain NixOS modules** — moving those
to Home Manager would mean re-deriving how `wrapper-modules` and the
native DMS module interact with a user-level profile, which is a much
bigger, riskier change than "add HM." `configuration.nix` keeps a bare
`programs.fish.enable = true;` — that's a genuinely separate concern
from HM's `programs.fish` (it's what registers fish in `/etc/shells`,
which is what makes `users.users.izo.shell = pkgs.fish` valid at all).

`home.stateVersion` is pinned to `"26.05"` in `home-manager.nix` —
bump it in lockstep with `system.stateVersion`, never independently.

### 2. MangoWC — both Niri and MangoWC selectable in the greeter

`my.compositors.mango.enable` (default `false` in `configuration.nix`)
now gates real content, not just a package: enabling it installs
`programs.mango` plus companion tools (`foot`, `wl-clipboard`, `grim`,
`slurp`, `swaybg`), and MangoWC gets its own home-manager-delivered
keybind file.

**On "give the option to select either at the greeter":**
`services.displayManager.dms-greeter.compositor.name` is a single
string, not a list — it sets the *default* session, it can't itself
declare "offer both." What actually makes both selectable is the
standard NixOS mechanism both compositors already use: each one's own
module registers a `.desktop` session file, and nixpkgs' release notes
describe `dms-greeter` as "supporting multiple Wayland compositors,"
which reads as its own UI enumerating that session list the way
GDM/SDDM do. **I can't verify that behavior from documentation alone —
this needs a real boot to confirm.** If both don't show up as a live
pick once you flip `my.compositors.mango.enable = true`, the fallback
is exactly what it was before: change `compositor.name` in
`dms-greeter.nix` between `"niri"` and `"mangowc"` and rebuild.

**Both compositors run DankMaterialShell** — `programs.dms-shell`
(`dms.nix`) isn't compositor-specific, and DMS lists MangoWC as a
first-class supported target alongside Niri, so this doesn't need
anything extra.

### 3. Default keybinds preserved on both compositors

This was the part worth getting right rather than guessing:

- **Niri** — `niri.nix`'s `binds{}` now reproduces niri's actual
  `resources/default-config.kdl` bind set in full (pulled from the
  niri-wm/niri repo directly, not memory), because niri's own docs are
  explicit that `binds{}` does **not** get filled in with defaults —
  a partial `binds{}` silently drops every unlisted bind. Only six
  binds deviate from stock: `Mod+Return`/`Mod+N`/`Mod+B`/`Mod+Space`
  are new (niri ships no default for these), and `Mod+Comma`/`Mod+V`
  deliberately override the stock `consume-window-into-column` /
  `toggle-window-floating` binds with DMS's settings/clipboard
  toggles. Everything else — arrow/vim navigation, workspace binds,
  screenshot keys, volume/media/brightness keys, `Mod+T`→alacritty,
  `Mod+D`→fuzzel, `Super+Alt+L`→swaylock — is niri's own default,
  unmodified. `alacritty`, `fuzzel`, `swaylock`, `playerctl`, and
  `brightnessctl` were added to `environment.systemPackages` so those
  stock binds actually resolve to something instead of "command not
  found."
- **MangoWC** — its real default table (confirmed from the
  mangowm/mango wiki): `Alt+Return`→foot, `Alt+Space`→rofi, `Alt+Q`
  →killclient, `Super+M`→quit, `Super+F`→fullscreen, `Alt+`arrows→focus,
  `Ctrl+1-9`→switch tag, `Alt+1-9`→move to tag. Rather than re-typing
  those (and risking getting an action keyword wrong — mango's config
  syntax has confirmed `spawn`/`killclient` verbs but I don't have
  certainty on all of them), `mango-keybinds.nix` `source`s mango's own
  shipped `/etc/mango/config.conf` — which the project's own docs
  describe as "a fallback configuration... you can use this as a
  reference" — and layers only the specified overrides on top
  (`Alt+Return`→ghostty, `Alt+Space`→DMS spotlight, plus new
  `Alt+N`/`Alt+B`/`Alt+Comma`/`Alt+V` binds). mango parses config files
  top-to-bottom with later binds winning, the same idiom its own wiki
  shows for exactly this kind of layering. This is delivered via
  home-manager (`xdg.configFile`) — the one place in the repo where a
  real per-user dotfile is the right tool, since mango has no
  wrapper-modules equivalent to niri's fully-baked-into-the-store
  approach.

### 4. HDA jack-retask is now an opt-in module

`modules/features/hda-jack-retask.nix` defines
`my.hardware.hdaJackRetask.{enable,firmwareFile}` instead of the
firmware-copy logic living inline in `configuration.nix`. This host
opts in and points at its own `./hda-jack-retask.fw`; a different host
in the same repo could set `enable = false` or supply a different
patch file entirely, without touching this module.

## Still on you

- Run `nix flake check` and `nixos-rebuild build --flake .#myMachine`
  — no `nix` binary in this environment, so none of this has been
  evaluated.
- The two flagged "unverified" items above (whether DankGreeter shows
  a live niri/mango picker, and whether the exact bind-property
  encoding for `allow-when-locked`/`cooldown-ms`/`repeat` in
  `niri.nix` matches what `wrapper-modules`' niri wrapper expects) are
  the two things most likely to need a small fix after a first real
  build — `niri validate` will catch the second one immediately if
  it's wrong.
- `helium-browser` is still a bet on it having landed in
  `nixpkgs/by-name` on your `nixos-unstable` pin — flag it if
  `nix flake check` disagrees.

## GRUB theme (stylish-wine-grub-theme.zip)

Vendored into `modules/hosts/my-machine/grub-theme/stylish/` — a
fully pre-rendered theme (fonts, icons, background, `theme.txt`), no
flake input or build-time generator needed.
`boot.loader.grub.theme = ./grub-theme/stylish;` in `configuration.nix`.
`elegant-wave-grub-themes` was removed from `flake.nix` since nothing
references it anymore — run `nix flake lock` once to prune the stale
entry out of `flake.lock`.

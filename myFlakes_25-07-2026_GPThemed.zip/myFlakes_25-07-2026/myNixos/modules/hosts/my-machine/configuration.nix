{ self, inputs, ... }: {

  flake.nixosModules.myMachineConfiguration = { pkgs, lib, ... }: {
    imports = [
      self.nixosModules.myMachineHardware
      self.nixosModules.niri
      self.nixosModules.dmsShell
      self.nixosModules.dmsGreeter
      self.nixosModules.mangoCompositor
      self.nixosModules.hdaJackRetask
      self.nixosModules.nautilusOpenAnyTerminal
      self.nixosModules.homeManager
      inputs.helium-browser.nixosModules.default
    ];

    # Both Niri and MangoWC are installed and available as sessions —
    # see mango.nix for the companion packages this pulls in and
    # dms-greeter.nix for how session selection works.
    my.compositors.mango.enable = true;

    # Firmware module is generic across hosts — this host opts in and
    # supplies its own patch file. See hda-jack-retask.nix.
    my.hardware.hdaJackRetask = {
      enable = true;
      firmwareFile = ./hda-jack-retask.fw;
    };

    nix.settings.experimental-features = [ "nix-command" "flakes" ];

    # ════════════════════════
    # Bootloader
    # ════════════════════════
    boot.loader.efi.canTouchEfiVariables = true;
    boot.supportedFilesystems = [ "ntfs" ];
    boot.loader.grub = {
      enable = true;
      device = "nodev";
      efiSupport = true;
      useOSProber = true;
      # Pinned to the actual panel resolution (1920x1080) rather than
      # left on GRUB's "auto" default. Without this, GRUB, the
      # kernel's own KMS handoff, and Plymouth can each pick a
      # different mode independently, which shows up as a resolution
      # flip / flash of text console between them — same class of
      # "theme doesn't work" symptom as the ImageDir bug above, just
      # a display-mode-continuity issue rather than a missing-file
      # one. gfxmodeEfi covers the systemd-boot/EFI GRUB path;
      # gfxmodeBios covers legacy BIOS boot for the same reason.
      gfxmodeEfi = "1920x1080";
      gfxmodeBios = "1920x1080";
    };
    # Static pre-rendered theme (vendored from stylish-wine-grub-theme.zip)
    # instead of the Elegant flake's build-time generator — no flake
    # input needed, this folder already has theme.txt + assets baked.
    boot.loader.grub.theme = ./grub-theme/stylish;

    # quiet+splash: suppress the kernel's text boot log so Plymouth's
    # graphical splash has the screen to itself instead of a wall of
    # scrolling text flashing underneath/before it.
    # Systemd-in-initrd: NixOS's Plymouth module builds two separate
    # copies of a theme — one baked into the initrd, one for the real
    # root post switch-root (/etc/plymouth/themes) — and the
    # classic/dracut-style initrd path (the default when this isn't
    # set) has historically been the buggier of the two for carrying
    # a custom `script`-module theme across that handoff cleanly;
    # nixpkgs has landed fixes specifically targeting the systemd
    # stage-1 path for this. Turning this on is what actually fixes
    # "theme flashes correctly right after GRUB, then reverts to
    # Plymouth's built-in grey/logo-in-the-corner fallback" — that
    # fallback (details/text/label) is what Plymouth always keeps on
    # hand as a safety net and drops to whenever it can't carry the
    # requested `script` module through to stage 2.
    boot.initrd.systemd.enable = true;

    boot.kernelParams = [ "quiet" "splash" ];
    boot.consoleLogLevel = 0;
    boot.initrd.verbose = false;

    # Plymouth boot splash — vendored "nixos-stylish" theme, designed to
    # match the GRUB theme above (same background, blurred + darkened).
    # Packaged via runCommand rather than boot.plymouth.themePackages
    # pointing straight at the folder, since Plymouth themes need to
    # land under share/plymouth/themes/<name>/ inside the derivation.
    #
    # Why it wasn't showing up: nixos-stylish.plymouth's [script]
    # section hardcodes ImageDir/ScriptFile as
    # /usr/share/plymouth/themes/nixos-stylish — an FHS path that
    # doesn't exist on NixOS (there is no /usr/share here; everything
    # lives under this derivation's own /nix/store/<hash>-... path).
    # `cp -r` alone copies the theme files but never rewrites those
    # two lines, so at boot Plymouth reads the .plymouth file, looks
    # for the script/images at a path that isn't there, and just
    # fails to render the theme (falls back to blank/default) instead
    # of erroring loudly. The `sed` below rewrites both paths to the
    # real $out location so Plymouth can actually find them.
    boot.plymouth = {
      enable = true;
      theme = "nixos-stylish";
      themePackages = [
        (pkgs.runCommand "nixos-stylish-plymouth" { } ''
          mkdir -p $out/share/plymouth/themes/nixos-stylish
          cp -r ${./plymouth-theme/nixos-stylish}/* $out/share/plymouth/themes/nixos-stylish/
          sed -i \
            "s|/usr/share/plymouth/themes/nixos-stylish|$out/share/plymouth/themes/nixos-stylish|g" \
            $out/share/plymouth/themes/nixos-stylish/nixos-stylish.plymouth
        '')
      ];
    };

    # ════════════════════════
    # Networking
    # ════════════════════════
    networking.hostName = "nixos";
    networking.networkmanager.enable = true;

    # ════════════════════════
    # Locale
    # ════════════════════════
    time.timeZone = "Africa/Nairobi";
    i18n.defaultLocale = "en_US.UTF-8";

    # ════════════════════════
    # Display / Session
    # ════════════════════════
    # GNOME + GDM + xserver removed. Two selectable compositors (Niri,
    # optionally MangoWC), one shell (DankMaterialShell) on either,
    # one greeter (DankGreeter, with autologin enabled — see
    # dms-greeter.nix). No X server, no display manager other than
    # DankGreeter itself.
    services.udisks2.enable = true;
    security.polkit.enable = true;

    # ════════════════════════
    # Bluetooth
    # ════════════════════════
    hardware.bluetooth = {
      enable = true;
      powerOnBoot = true;
    };
    # No separate GUI agent package added — DMS's own bluetooth widget
    # (part of programs.dms-shell, dms.nix) talks to bluez directly.

    # ════════════════════════
    # Audio
    # ════════════════════════
    services.printing.enable = true;
    services.pulseaudio.enable = false;
    security.rtkit.enable = true;
    services.pipewire = {
      enable = true;
      alsa.enable = true;
      alsa.support32Bit = true;
      pulse.enable = true;
    };

    # ════════════════════════
    # Shell
    # ════════════════════════
    # Actual Fish config (aliases, prompt colors, functions) is now
    # home-manager-managed — modules/features/fish.nix defines
    # flake.homeModules.fishShell, wired into izo's profile in
    # home-manager.nix. This system-level enable is still required
    # even so: it's what registers fish in /etc/shells, which is what
    # makes `users.users.izo.shell = pkgs.fish` below valid. Home
    # Manager's own programs.fish module does NOT do this — it's a
    # system-level concern, not a per-user one.
    programs.fish.enable = true;

    # ════════════════════════
    # User
    # ════════════════════════
    users.users."izo" = {
      isNormalUser = true;
      description = "izo";
      extraGroups = [ "networkmanager" "wheel" "storage" "disk" ];
      packages = with pkgs; [ ];
      shell = pkgs.fish;
    };

    # Helium browser — via the oxcl/nix-flake-helium-browser module
    # imported above (nixpkgs has no helium-browser attribute; the
    # official nixpkgs PR is still pending).
    programs.helium = {
      enable = true;
      flags = [ "--ozone-platform-hint=auto" ]; # native Wayland under niri/mango
    };

    # ════════════════════════
    # Packages
    # ════════════════════════
    programs.firefox.enable = true;
    nixpkgs.config.allowUnfree = true;

    environment.systemPackages = with pkgs; [
      brave
      zed-editor
      ghostty
      nano
      git
      htop
      mpv
      imv
      yazi
      neovim
      nautilus
      zathura
      ntfs3g
      fastfetch

      # --- yazi extras ---
      ripgrep       # in-file fuzzy search (yazi's built-in search)
      fd            # fast file search / jump
      poppler-utils # PDF thumbnail previews (pairs with zathura)
      jq            # pretty-printed JSON previews
      unar          # archive (zip/rar/7z) content previews
      # Image previews need no extra package: Ghostty supports the
      # Kitty graphics protocol natively, which yazi uses directly.

      # --- niri's stock default keybinds (see niri.nix) spawn these ---
      alacritty     # Mod+T
      fuzzel        # Mod+D
      swaylock      # Super+Alt+L
      playerctl     # XF86Audio{Play,Pause,Stop,Prev,Next}
      brightnessctl # XF86MonBrightness{Up,Down}

      # lxqt.lxqt-policykit intentionally dropped — DMS ships its own
      # polkit agent (programs.dms-shell, dms.nix). Running both would
      # race for the same D-Bus polkit auth-agent registration.
    ];

    system.stateVersion = "26.05";
  };
}

{ ... }: {
  # ════════════════════════════════════════════════════════════════
  # Icon themes: all four variants below get installed so their icon
  # sets are on disk (under home.packages -> ~/.nix-profile/share/
  # icons, which is on XDG_DATA_DIRS, so icon lookups can fall
  # through to any of them) but only Kora is declared as the *active*
  # gtk.iconTheme — GTK itself only supports one active icon theme
  # name/package pair at a time, so "active" here just means which
  # name ends up in ~/.config/gtk-3.0 / gtk-4.0 settings.ini. Swapping
  # which one is active later is a one-line change to the `name` /
  # `package` pair below (Uos -> uosIconsWithFallback, Tela ->
  # telaIcons, Newaita-reborn -> newaitaRebornIconsWithFallback).
  #
  # librsvg is included in home.packages too: several of these themes
  # ship scalable/*.svg fallback icons alongside their PNG/hicolor
  # sets, and GTK's icon loader needs librsvg's gdk-pixbuf loader
  # present to rasterize those at all — without it, apps silently
  # fall back to a broken-image icon for anything not covered by a
  # PNG at the requested size.
  # ════════════════════════════════════════════════════════════════
  flake.homeModules.iconThemes = { pkgs, lib, ... }:
    let
      # ── Uos — deepin/UOS icon set. Not in nixpkgs, packaged
      # directly from upstream. Repo layout confirmed from
      # github.com/zayronxio/Uos-fulldistro-icons: a single flat
      # theme directory at repo root (actions/, apps/64/, cursors/,
      # devices/, emblems/24/, mimetypes/, places/, status/, plus
      # index.theme, cursor.theme, icon-theme.cache). index.theme
      # declares `Name=Uos`, `Inherits=breeze,gnome,hicolor`, and
      # `FollowsColorScheme=true`. Repo hasn't been pushed to since
      # Jan 2021 (last commit on `master`), so this is pinned to the
      # tip of `master` by branch rather than a tag — no releases/
      # tags exist upstream either.
      uosIcons = pkgs.stdenvNoCC.mkDerivation {
        pname = "uos-icon-theme";
        version = "unstable-2026-07-24";

        src = pkgs.fetchFromGitHub {
          owner = "zayronxio";
          repo = "Uos-fulldistro-icons";
          rev = "master";
          # Placeholder — nixpkgs has no prebuilt hash for this repo
          # since it's fetched straight from GitHub. First
          # `nixos-rebuild` will fail with a hash mismatch error that
          # prints the real sha256-... value; paste it in here in
          # place of fakeHash.
          hash = "sha256-s5g/5WGmz0cVJ3gbnwS7kXVjup6BCvVefCyu976Gz1I=";
        };

        dontBuild = true;

        # Inherits=breeze,gnome,hicolor in index.theme means contexts
        # this theme doesn't cover itself fall through to those
        # parents at lookup time, so keep the same
        # belt-and-suspenders skip here in case upstream ships any
        # symlink that doesn't resolve inside this repo alone.
        dontCheckForBrokenSymlinks = true;

        installPhase = ''
          runHook preInstall
          mkdir -p $out/share/icons/Uos
          cp -r . $out/share/icons/Uos
          runHook postInstall
        '';

        meta = with pkgs.lib; {
          description = "Uos icon theme (deepin/UOS desktop icon set)";
          homepage = "https://github.com/zayronxio/Uos-fulldistro-icons";
          # No LICENSE file upstream as of this writing — unspecified.
          platforms = platforms.all;
        };
      };

      # Bundle Breeze so the Inherits=breeze fallback in index.theme
      # actually resolves instead of depending on a system Breeze
      # install that may not be present.
      uosIconsWithFallback = pkgs.symlinkJoin {
        name = "uos-icon-theme-with-fallback";
        paths = [ uosIcons pkgs.kdePackages.breeze-icons ];
      };

      # ── Kora — already packaged in nixpkgs as `kora-icon-theme`,
      # so no custom fetchFromGitHub derivation needed. index.theme
      # declares `Inherits=breeze,gnome,hicolor`, same fallback chain
      # as Uos, but since this comes from nixpkgs proper rather than
      # a raw upstream checkout there's no known-missing-symlink
      # footgun to route around, so it's used directly.
      koraIcons = pkgs.kora-icon-theme;

      # ── Tela — also packaged in nixpkgs as `tela-icon-theme`.
      # Upstream shipped a handful of dangling symlinks
      # (nixpkgs#381521) that used to fail the build's
      # noBrokenSymlinks check; fixed on the nixpkgs side as of PR
      # #382288 (`tela-icon-theme: don't check for broken symlinks`),
      # so this is a plain package reference same as Kora.
      telaIcons = pkgs.tela-icon-theme;

      # ── Newaita-reborn — not in nixpkgs, packaged directly from
      # upstream same as Uos. Repo layout confirmed from
      # github.com/cbrnix/Newaita-reborn: no single flat theme dir
      # like Uos — instead ~26 top-level folders at repo root, one
      # per color variant (Newaita-reborn, Newaita-reborn-dark,
      # Newaita-reborn-nord, Newaita-reborn-dracula, ...) each with
      # its own index.theme, plus non-theme cruft (LICENSE,
      # README.md, cover.png, icon.png, .directory) that isn't a
      # theme dir and must be skipped. installPhase below copies
      # every `Newaita-reborn*` folder so all color variants are
      # available and selectable by name, not just the two default
      # light/dark ones.
      newaitaRebornIcons = pkgs.stdenvNoCC.mkDerivation {
        pname = "newaita-reborn-icon-theme";
        version = "unstable-2026-07-24";

        src = pkgs.fetchFromGitHub {
          owner = "cbrnix";
          repo = "Newaita-reborn";
          rev = "master";
          # Placeholder — nixpkgs has no prebuilt hash for this repo.
          # First `nixos-rebuild` will fail with a hash mismatch
          # error that prints the real sha256-... value; paste it in
          # here in place of fakeHash.
          hash = "sha256-s5g/5WGmz0cVJ3gbnwS7kXVjup6BCvVefCyu976Gz1I=";
        };

        dontBuild = true;

        # Same belt-and-suspenders as Uos in case an upstream variant
        # folder ships a symlink that doesn't resolve inside this
        # repo alone.
        dontCheckForBrokenSymlinks = true;

        installPhase = ''
          runHook preInstall
          mkdir -p $out/share/icons
          for d in Newaita-reborn*; do
            cp -r "$d" "$out/share/icons/$d"
          done
          runHook postInstall
        '';

        meta = with pkgs.lib; {
          description = "Newaita-reborn icon theme (remaster of Newaita)";
          homepage = "https://github.com/cbrnix/Newaita-reborn";
          license = licenses.gpl3Only;
          platforms = platforms.all;
        };
      };

      # Same reasoning as Uos: bundle Breeze so the
      # Inherits=breeze,gnome,hicolor fallback in each variant's
      # index.theme actually resolves.
      newaitaRebornIconsWithFallback = pkgs.symlinkJoin {
        name = "newaita-reborn-icon-theme-with-fallback";
        paths = [ newaitaRebornIcons pkgs.kdePackages.breeze-icons ];
      };
    in
    {
      home.packages = [
        uosIconsWithFallback
        koraIcons
        telaIcons
        newaitaRebornIconsWithFallback
        pkgs.librsvg
      ];

      gtk = {
        enable = true;

        # Active icon theme: Kora. The other three are installed
        # above (available on XDG_DATA_DIRS for anything that looks
        # them up by name directly) but not declared active here.
        iconTheme = {
          name = "Kora";
          package = koraIcons;
        };

        # Default GTK widget theme: Adwaita, GTK's own stock theme.
        # gnome-themes-extra is what actually ships the
        # Adwaita/Adwaita-dark/HighContrast GTK2+GTK3 theme files —
        # GTK4/libadwaita apps render Adwaita themselves with no
        # separate theme package needed, but GTK3 apps look up an
        # installed "Adwaita" theme dir, so this package covers both.
        theme = {
          name = "Adwaita";
          package = pkgs.gnome-themes-extra;
        };
      };

      # DMS's dynamic theming (matugen, dms.nix) recolors GTK/Qt
      # accent colors live but doesn't ship its own icon set, so this
      # doesn't conflict with it the way a live-templated GTK config
      # would.
    };
}

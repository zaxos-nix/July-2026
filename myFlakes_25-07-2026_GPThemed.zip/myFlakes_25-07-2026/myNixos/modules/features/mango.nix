{ inputs, lib, ... }: {
  flake.nixosModules.mangoCompositor = { config, pkgs, ... }:
    let
      cfg = config.my.compositors.mango;
    in
    {
      imports = [ inputs.mango.nixosModules.mango ];

      options.my.compositors.mango.enable = lib.mkEnableOption ''
        MangoWC as an optional second compositor alongside Niri, both
        running DankMaterialShell. Off by default — flip to true to
        install it.
      '';

      config = lib.mkIf cfg.enable {
        programs.mango.enable = true;

        # Companion packages mango's default config.conf expects
        # (terminal, clipboard, screenshot, wallpaper tools). Gated
        # behind this toggle rather than always-installed, to keep
        # this a genuinely optional feature.
        environment.systemPackages = with pkgs; [
          foot
          wl-clipboard
          grim
          slurp
          swaybg
        ];

        # DMS lists MangoWC as a first-class supported compositor.
        # Actual keybind overrides (matching niri.nix's app binds) are
        # home-manager-managed — see mango-keybinds.nix / home-manager.nix
        # — since mango has no wrapper-modules integration and its
        # config lives in a normal per-user dotfile, unlike niri's.

        # The mango NixOS module should register its own wayland-session
        # .desktop entry the same way niri's does, which is what lets a
        # session-aware greeter list it as a choice — this is the
        # mechanism dms-greeter.nix is counting on to offer both
        # sessions. Whether DankGreeter's UI actually surfaces both as
        # a live picker is the unverified part flagged there; confirm
        # at the login screen after a rebuild with this enabled.
      };
    };
}

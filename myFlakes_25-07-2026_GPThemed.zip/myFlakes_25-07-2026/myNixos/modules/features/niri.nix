{ self, inputs, ... }: {
  flake.nixosModules.niri = { pkgs, ... }: {
    programs.niri = {
      enable = true;
      package = self.packages.${pkgs.stdenv.hostPlatform.system}.myNiri;
    };
  };

  perSystem = { pkgs, lib, self', ... }: {
    packages.myNiri = inputs.wrapper-modules.wrappers.niri.wrap {
      inherit pkgs;
      v2-settings = true;
      settings = {

        hotkey-overlay = {
          skip-at-startup = true;
        };

        input = {
          keyboard.xkb = {
            layout = "us";
          };
          touchpad = {
            tap = [ ];
          };
        };

        outputs."eDP-1" = {
          scale = 1.0;
          transform = "normal";
        };

        layout = {
          gaps = 4;
          center-focused-column = "never";

          default-column-width = { proportion = 1.0; };

          preset-column-widths = [
            { proportion = 0.33333; }
            { proportion = 0.5; }
            { proportion = 0.66667; }
          ];

          focus-ring = {
            width = 2;
            active-color = "#7fc8ff";
            inactive-color = "#505050";
          };

          border = {
            off = [ ];
          };
        };

        prefer-no-csd = [ ];

        # No spawn-at-startup entries: DMS starts itself via its own
        # systemd user service (programs.dms-shell.systemd, dms.nix)
        # and ships its own polkit agent.
        spawn-at-startup = [ ];

        # ════════════════════════════════════════════════════════════
        # KEYBINDINGS — niri's full stock resources/default-config.kdl
        # binds section (niri-wm/niri, current main), reproduced here
        # verbatim (niri does NOT fill binds{} with defaults when the
        # section is present at all — the wiki calls this out
        # explicitly — so a partial binds block silently drops every
        # bind not listed). Only the binds under "--- app overrides
        # ---" below deviate from stock:
        #   Mod+Return, Mod+N, Mod+B, Mod+Space  -> new, no default
        #     conflict (niri ships no default for these)
        #   Mod+Comma, Mod+V -> DELIBERATE overrides of the stock
        #     consume-window-into-column / toggle-window-floating
        #     binds, replaced with DMS's settings/clipboard toggles
        # Everything else below is niri's own default, unmodified —
        # including the alacritty/fuzzel/swaylock/playerctl/
        # brightnessctl spawns, which is why those packages are in
        # configuration.nix now.
        # ════════════════════════════════════════════════════════════
        binds = {
          "Mod+Shift+Slash" = { show-hotkey-overlay = [ ]; };

          "Mod+T" = { spawn = [ "alacritty" ]; };
          "Mod+D" = { spawn = [ "fuzzel" ]; };
          "Super+Alt+L" = { spawn = [ "swaylock" ]; };

          "XF86AudioRaiseVolume" = _: {
            props.allow-when-locked = true;
            content.spawn-sh = "wpctl set-volume @DEFAULT_AUDIO_SINK@ 0.1+ -l 1.0";
          };
          "XF86AudioLowerVolume" = _: {
            props.allow-when-locked = true;
            content.spawn-sh = "wpctl set-volume @DEFAULT_AUDIO_SINK@ 0.1-";
          };
          "XF86AudioMute" = _: {
            props.allow-when-locked = true;
            content.spawn-sh = "wpctl set-mute @DEFAULT_AUDIO_SINK@ toggle";
          };
          "XF86AudioMicMute" = _: {
            props.allow-when-locked = true;
            content.spawn-sh = "wpctl set-mute @DEFAULT_AUDIO_SOURCE@ toggle";
          };

          "XF86AudioPlay" = _: {
            props.allow-when-locked = true;
            content.spawn-sh = "playerctl play-pause";
          };
          "XF86AudioPause" = _: {
            props.allow-when-locked = true;
            content.spawn-sh = "playerctl play-pause";
          };
          "XF86AudioStop" = _: {
            props.allow-when-locked = true;
            content.spawn-sh = "playerctl stop";
          };
          "XF86AudioPrev" = _: {
            props.allow-when-locked = true;
            content.spawn-sh = "playerctl previous";
          };
          "XF86AudioNext" = _: {
            props.allow-when-locked = true;
            content.spawn-sh = "playerctl next";
          };

          "XF86MonBrightnessUp" = _: {
            props.allow-when-locked = true;
            content.spawn = [ "brightnessctl" "--class=backlight" "set" "+10%" ];
          };
          "XF86MonBrightnessDown" = _: {
            props.allow-when-locked = true;
            content.spawn = [ "brightnessctl" "--class=backlight" "set" "10%-" ];
          };

          "Mod+O" = _: {
            props.repeat = false;
            content.toggle-overview = [ ];
          };

          "Mod+Q" = _: {
            props.repeat = false;
            content.close-window = [ ];
          };

          "Mod+Left"  = { focus-column-left = [ ]; };
          "Mod+Down"  = { focus-window-down = [ ]; };
          "Mod+Up"    = { focus-window-up = [ ]; };
          "Mod+Right" = { focus-column-right = [ ]; };
          "Mod+H"     = { focus-column-left = [ ]; };
          "Mod+J"     = { focus-window-down = [ ]; };
          "Mod+K"     = { focus-window-up = [ ]; };
          "Mod+L"     = { focus-column-right = [ ]; };

          "Mod+Ctrl+Left"  = { move-column-left = [ ]; };
          "Mod+Ctrl+Down"  = { move-window-down = [ ]; };
          "Mod+Ctrl+Up"    = { move-window-up = [ ]; };
          "Mod+Ctrl+Right" = { move-column-right = [ ]; };
          "Mod+Ctrl+H"     = { move-column-left = [ ]; };
          "Mod+Ctrl+J"     = { move-window-down = [ ]; };
          "Mod+Ctrl+K"     = { move-window-up = [ ]; };
          "Mod+Ctrl+L"     = { move-column-right = [ ]; };

          "Mod+Home" = { focus-column-first = [ ]; };
          "Mod+End"  = { focus-column-last = [ ]; };
          "Mod+Ctrl+Home" = { move-column-to-first = [ ]; };
          "Mod+Ctrl+End"  = { move-column-to-last = [ ]; };

          "Mod+Shift+Left"  = { focus-monitor-left = [ ]; };
          "Mod+Shift+Down"  = { focus-monitor-down = [ ]; };
          "Mod+Shift+Up"    = { focus-monitor-up = [ ]; };
          "Mod+Shift+Right" = { focus-monitor-right = [ ]; };
          "Mod+Shift+H"     = { focus-monitor-left = [ ]; };
          "Mod+Shift+J"     = { focus-monitor-down = [ ]; };
          "Mod+Shift+K"     = { focus-monitor-up = [ ]; };
          "Mod+Shift+L"     = { focus-monitor-right = [ ]; };

          "Mod+Shift+Ctrl+Left"  = { move-column-to-monitor-left = [ ]; };
          "Mod+Shift+Ctrl+Down"  = { move-column-to-monitor-down = [ ]; };
          "Mod+Shift+Ctrl+Up"    = { move-column-to-monitor-up = [ ]; };
          "Mod+Shift+Ctrl+Right" = { move-column-to-monitor-right = [ ]; };
          "Mod+Shift+Ctrl+H"     = { move-column-to-monitor-left = [ ]; };
          "Mod+Shift+Ctrl+J"     = { move-column-to-monitor-down = [ ]; };
          "Mod+Shift+Ctrl+K"     = { move-column-to-monitor-up = [ ]; };
          "Mod+Shift+Ctrl+L"     = { move-column-to-monitor-right = [ ]; };

          "Mod+Page_Down"      = { focus-workspace-down = [ ]; };
          "Mod+Page_Up"        = { focus-workspace-up = [ ]; };
          "Mod+U"              = { focus-workspace-down = [ ]; };
          "Mod+I"              = { focus-workspace-up = [ ]; };
          "Mod+Ctrl+Page_Down" = { move-column-to-workspace-down = [ ]; };
          "Mod+Ctrl+Page_Up"   = { move-column-to-workspace-up = [ ]; };
          "Mod+Ctrl+U"         = { move-column-to-workspace-down = [ ]; };
          "Mod+Ctrl+I"         = { move-column-to-workspace-up = [ ]; };

          "Mod+Shift+Page_Down" = { move-workspace-down = [ ]; };
          "Mod+Shift+Page_Up"   = { move-workspace-up = [ ]; };
          "Mod+Shift+U"         = { move-workspace-down = [ ]; };
          "Mod+Shift+I"         = { move-workspace-up = [ ]; };

          "Mod+WheelScrollDown" = _: {
            props.cooldown-ms = 150;
            content.focus-workspace-down = [ ];
          };
          "Mod+WheelScrollUp" = _: {
            props.cooldown-ms = 150;
            content.focus-workspace-up = [ ];
          };
          "Mod+Ctrl+WheelScrollDown" = _: {
            props.cooldown-ms = 150;
            content.move-column-to-workspace-down = [ ];
          };
          "Mod+Ctrl+WheelScrollUp" = _: {
            props.cooldown-ms = 150;
            content.move-column-to-workspace-up = [ ];
          };

          "Mod+WheelScrollRight"      = { focus-column-right = [ ]; };
          "Mod+WheelScrollLeft"       = { focus-column-left = [ ]; };
          "Mod+Ctrl+WheelScrollRight" = { move-column-right = [ ]; };
          "Mod+Ctrl+WheelScrollLeft"  = { move-column-left = [ ]; };

          "Mod+Shift+WheelScrollDown"      = { focus-column-right = [ ]; };
          "Mod+Shift+WheelScrollUp"        = { focus-column-left = [ ]; };
          "Mod+Ctrl+Shift+WheelScrollDown" = { move-column-right = [ ]; };
          "Mod+Ctrl+Shift+WheelScrollUp"   = { move-column-left = [ ]; };

          "Mod+1" = { focus-workspace = 1; };
          "Mod+2" = { focus-workspace = 2; };
          "Mod+3" = { focus-workspace = 3; };
          "Mod+4" = { focus-workspace = 4; };
          "Mod+5" = { focus-workspace = 5; };
          "Mod+6" = { focus-workspace = 6; };
          "Mod+7" = { focus-workspace = 7; };
          "Mod+8" = { focus-workspace = 8; };
          "Mod+9" = { focus-workspace = 9; };
          "Mod+Ctrl+1" = { move-column-to-workspace = 1; };
          "Mod+Ctrl+2" = { move-column-to-workspace = 2; };
          "Mod+Ctrl+3" = { move-column-to-workspace = 3; };
          "Mod+Ctrl+4" = { move-column-to-workspace = 4; };
          "Mod+Ctrl+5" = { move-column-to-workspace = 5; };
          "Mod+Ctrl+6" = { move-column-to-workspace = 6; };
          "Mod+Ctrl+7" = { move-column-to-workspace = 7; };
          "Mod+Ctrl+8" = { move-column-to-workspace = 8; };
          "Mod+Ctrl+9" = { move-column-to-workspace = 9; };

          "Mod+BracketLeft"  = { consume-or-expel-window-left = [ ]; };
          "Mod+BracketRight" = { consume-or-expel-window-right = [ ]; };

          "Mod+Period" = { expel-window-from-column = [ ]; };

          "Mod+R"       = { switch-preset-column-width = [ ]; };
          "Mod+Shift+R" = { switch-preset-column-width-back = [ ]; };

          "Mod+Ctrl+Shift+R" = { switch-preset-window-height = [ ]; };
          "Mod+Ctrl+R"       = { reset-window-height = [ ]; };

          "Mod+F"       = { maximize-column = [ ]; };
          "Mod+Shift+F" = { fullscreen-window = [ ]; };

          "Mod+M"       = { maximize-window-to-edges = [ ]; };
          "Mod+Ctrl+F"  = { expand-column-to-available-width = [ ]; };

          "Mod+C"       = { center-column = [ ]; };
          "Mod+Ctrl+C"  = { center-visible-columns = [ ]; };

          "Mod+Minus" = { set-column-width = "-10%"; };
          "Mod+Equal" = { set-column-width = "+10%"; };
          "Mod+Shift+Minus" = { set-window-height = "-10%"; };
          "Mod+Shift+Equal" = { set-window-height = "+10%"; };

          "Mod+Shift+V" = { switch-focus-between-floating-and-tiling = [ ]; };

          "Mod+W" = { toggle-column-tabbed-display = [ ]; };

          "Print"      = { screenshot = [ ]; };
          "Ctrl+Print" = { screenshot-screen = [ ]; };
          "Alt+Print"  = { screenshot-window = [ ]; };

          "Mod+Escape" = _: {
            props.allow-inhibiting = false;
            content.toggle-keyboard-shortcuts-inhibit = [ ];
          };

          "Mod+Shift+E"     = { quit = [ ]; };
          "Ctrl+Alt+Delete" = { quit = [ ]; };

          "Mod+Shift+P" = { power-off-monitors = [ ]; };

          # --- app overrides (see comment block above) ---
          "Mod+Return" = { spawn = [ (lib.getExe pkgs.ghostty) ]; };
          "Mod+N"      = { spawn = [ (lib.getExe pkgs.nautilus) ]; };
          "Mod+B"      = { spawn = [ (lib.getExe pkgs.brave) ]; };
          "Mod+Space".spawn-sh = "dms ipc call spotlight toggle";
          "Mod+Comma".spawn-sh = "dms ipc call settings toggle";
          "Mod+V".spawn-sh     = "dms ipc call clipboard toggle";
        };
      };
    };
  };
}

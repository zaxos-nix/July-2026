{ ... }: {
  # ════════════════════════════════════════════════════════════════
  # Adds "Open Terminal Here" (ghostty) to Nautilus's right-click menu,
  # via nixpkgs' native `programs.nautilus-open-any-terminal` module
  # (nixos/modules/programs/nautilus-open-any-terminal.nix). That
  # module already does everything a GNOME-less setup like this one
  # needs on its own: installs `nautilus-python` + the extension,
  # points NAUTILUS_4_EXTENSION_DIR at it (only when
  # services.desktopManager.gnome isn't enabled, which is exactly this
  # repo's case — GNOME/GDM was removed, see configuration.nix), links
  # `/share/nautilus-python/extensions` into the system path, and
  # writes the "which terminal" choice into the system dconf profile
  # itself (locked, not user-overridable) — no manual
  # sessionVariables/pathsToLink wiring needed on top.
  #
  # Ghostty specifically needs one more thing the extension's own
  # README calls out: with Ghostty's default GTK single-instance mode,
  # a second `ghostty --working-directory=...` invocation just gets
  # forwarded to the already-running instance, which ignores the
  # working-directory flag entirely — so right-click "Open Terminal"
  # would silently open in the wrong folder once any Ghostty window is
  # already open. `gtk-single-instance = false` (ghostty.nix, new
  # ~/.config/ghostty/config) is what makes the working-directory flag
  # actually get honored on every invocation, not just the first.
  flake.nixosModules.nautilusOpenAnyTerminal = { ... }: {
    programs.nautilus-open-any-terminal = {
      enable = true;
      terminal = "ghostty";
    };
  };

  # Companion Ghostty config: without this, the fix above is
  # incomplete — see the comment on gtk-single-instance itself for why.
  flake.homeModules.ghosttyConfig = { ... }: {
    xdg.configFile."ghostty/config".text = ''
      # Required for nautilus-open-any-terminal (nautilus-terminal.nix)
      # to actually open at the right-clicked directory instead of
      # just focusing whatever Ghostty window already happens to be
      # open. See: https://github.com/Stunkymonkey/nautilus-open-any-terminal
      gtk-single-instance = false
    '';
  };
}

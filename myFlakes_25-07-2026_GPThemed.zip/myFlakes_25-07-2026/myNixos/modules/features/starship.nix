{ ... }: {
  flake.homeModules.starshipPrompt = { lib, ... }: {
    # Home Manager's programs.starship wires itself into
    # programs.fish.enable automatically — no separate integration step.
    #
    # Named ANSI colors rather than fixed hex, same reasoning as
    # fish.nix: DMS owns Ghostty's live palette (enableDynamicTheming /
    # matugen, see dms.nix), so named colors track whatever theme is
    # currently active instead of asserting a second, competing one.
    programs.starship = {
      enable = true;

      settings = {
        add_newline = true;
        command_timeout = 1000;
        scan_timeout = 30;

        format = lib.concatStrings [
          "$username"
          "$hostname"
          "$directory"
          "$git_branch"
          "$git_status"
          "$nix_shell"
          "$cmd_duration"
          "$line_break"
          "$character"
        ];

        username = {
          style_user = "bold magenta";
          style_root = "bold red";
          format = "[$user]($style) ";
          show_always = false;
        };

        hostname = {
          ssh_only = true;
          format = "on [$hostname]($style) ";
          style = "bold yellow";
        };

        directory = {
          style = "bold blue";
          truncation_length = 3;
          truncate_to_repo = true;
        };

        git_branch = {
          symbol = " ";
          style = "bold magenta";
          format = "[$symbol$branch]($style) ";
        };

        git_status = {
          style = "bold yellow";
          format = "([$all_status$ahead_behind]($style)) ";
        };

        nix_shell = {
          symbol = " ";
          style = "bold cyan";
          format = "[$symbol$name]($style) ";
        };

        cmd_duration = {
          min_time = 2000;
          style = "bold yellow";
          format = "took [$duration]($style) ";
        };

        character = {
          success_symbol = "[➜](bold green)";
          error_symbol = "[➜](bold red)";
        };
      };
    };
  };
}

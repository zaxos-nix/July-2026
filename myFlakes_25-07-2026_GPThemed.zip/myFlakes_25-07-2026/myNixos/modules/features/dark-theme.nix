{ ... }: {
  # ════════════════════════════════════════════════════════════════
  # Forces dark mode as the system default, independent of whatever
  # DMS's own matugen-driven dynamic theming (dms.nix,
  # enableDynamicTheming) later derives from the active wallpaper.
  #
  # Two things needed, because "dark theme" means different things to
  # different toolkits on a portal-less niri/mango + GTK stack:
  #
  # 1. `org/gnome/desktop/interface color-scheme = prefer-dark` — the
  #    freedesktop-standard hint. GTK4/libadwaita apps (and Qt6 apps
  #    via xdg-desktop-portal, when one is running) read this to pick
  #    light vs dark automatically. dconf is the standard place
  #    xdg-desktop-portal's Settings backend reads it from even
  #    without a full GNOME session present.
  # 2. `gtk-application-prefer-dark-theme` in GTK3/GTK4 — older GTK3
  #    apps (and some GTK4 apps that don't check the portal) look at
  #    this flag directly instead. Belt-and-suspenders with #1.
  #
  # NOT covered by this file: DMS's own in-shell light/dark toggle
  # (Mod+Comma → dms ipc call settings toggle, per niri.nix/
  # mango-keybinds.nix) is separate app-level UI state that DMS stores
  # itself at runtime — it isn't exposed as a NixOS/home-manager
  # option (checked against the current programs.dms-shell module),
  # so it can't be pinned declaratively here. Toggle it once by hand
  # on first login if DMS itself still comes up light.
  # ════════════════════════════════════════════════════════════════
  flake.homeModules.darkTheme = { ... }: {
    dconf.settings."org/gnome/desktop/interface" = {
      color-scheme = "prefer-dark";
    };

    gtk.gtk3.extraConfig."gtk-application-prefer-dark-theme" = 1;
    gtk.gtk4.extraConfig."gtk-application-prefer-dark-theme" = 1;
  };
}

{ ... }: {
  # ════════════════════════════════════════════════════════════════
  # DankGreeter, native nixpkgs 26.05+ module. Replaces GDM/GNOME
  # (services.xserver / services.displayManager.gdm /
  # services.desktopManager.gnome, all removed from configuration.nix).
  #
  # Greeter is fully configured and themed, but autoLogin is also
  # enabled on top, so boot skips straight to the default session
  # without stopping at the password prompt. Flip
  # `services.displayManager.autoLogin.enable` to false any time to get
  # the interactive DankGreeter login screen back — no other changes
  # needed.
  #
  # --- Selecting between Niri and MangoWC ---
  # `compositor.name` below only sets the *default* session — it's a
  # single string, not a list, so it can't itself declare "offer both."
  # What actually makes both selectable is the standard NixOS
  # mechanism: each compositor's own module (programs.niri.enable,
  # programs.mango.enable when my.compositors.mango.enable = true —
  # see niri.nix / mango.nix) registers its own wayland-session
  # .desktop entry under /run/current-system/sw/share/wayland-sessions/.
  # nixpkgs' own release notes describe dms-greeter as "supporting
  # multiple Wayland compositors," which reads as the greeter's QML UI
  # enumerating that session list itself, the same way GDM/SDDM do —
  # but I can't verify that behavior from documentation alone. If both
  # sessions do NOT show up as a live pick after enabling MangoWC,
  # switching becomes: change `compositor.name` below to "mango" (NOT
  # "mangowc" — confirmed from upstream's own assets/mango.desktop:
  # the file is named mango.desktop with DesktopNames=mango;wlroots,
  # so "mango" is the session id the greeter/display-manager actually
  # sees) and rebuild, the same as any other feature-flag switch in
  # this repo.
  #
  # Separately: if Mango *is* selectable and authentication succeeds
  # but the desktop looks broken/empty afterwards, that's most likely
  # not a greeter problem at all — see mango-keybinds.nix for why DMS's
  # shell doesn't start under Mango and the exec-once fix for it.
  # ════════════════════════════════════════════════════════════════
  flake.nixosModules.dmsGreeter = { ... }: {
    services.displayManager.dms-greeter = {
      enable = true;
      compositor.name = "niri"; # default/preselected session

      # Syncs izo's DMS theme/wallpaper to the greeter so it isn't a
      # jarring default-theme flash before autologin hands off.
      configHome = "/home/izo";
    };

    services.displayManager.autoLogin = {
      enable = true;
      user = "izo";
    };

    # Required even with autoLogin: this is how the display-manager
    # module knows which session's .desktop entry to launch by default.
    services.displayManager.defaultSession = "niri";
  };
}

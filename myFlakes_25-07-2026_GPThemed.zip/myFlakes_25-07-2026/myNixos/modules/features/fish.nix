{ ... }: {
  # Home-manager module (not a NixOS module) — imported into
  # home-manager.users.izo by home-manager.nix. Home Manager's
  # programs.fish has a real `functions` option, unlike the plain
  # NixOS module, so mkcd/fish_greeting no longer need to live inside
  # a raw interactiveShellInit string.
  flake.homeModules.fishShell = { ... }: {
    programs.fish = {
      enable = true;

      shellAliases = {
        ll  = "ls -lh";
        la  = "ls -lAh";
        gs  = "git status";
        gd  = "git diff";
        gc  = "git commit";
        gp  = "git push";
        nrs = "sudo nixos-rebuild switch --flake .#myMachine";
        nrb = "sudo nixos-rebuild boot --flake .#myMachine";
        nfu = "nix flake update";
        v   = "zeditor";
      };

      shellAbbrs = {
        gco   = "git checkout";
        gaa   = "git add --all";
        gcm   = "git commit -m";
        ".."  = "cd ..";
        "..." = "cd ../..";
      };

      functions = {
        mkcd = {
          description = "Create a directory (with parents) and cd into it";
          body = "mkdir -p $argv[1]; and cd $argv[1]";
        };
        # Empty, not just removed: without an override, Fish falls
        # back to its own built-in "Welcome to fish" banner instead of
        # fastfetch — still an autorun message on every new terminal,
        # just not the one being removed here.
        fish_greeting.body = "";
      };

      shellInit = ''
        # --- Colored completions ---
        # Named ANSI colors rather than fixed hex: DankMaterialShell
        # owns the live color scheme (enableDynamicTheming / matugen in
        # dms.nix) and pushes it into Ghostty's 16-color terminal
        # palette via its own theming pipeline. Naming colors here
        # instead of hardcoding hex means Fish's completions always
        # track whatever theme DMS currently has active.
        set -g fish_color_normal        normal
        set -g fish_color_command       blue
        set -g fish_color_param         normal
        set -g fish_color_keyword       magenta
        set -g fish_color_quote         green
        set -g fish_color_redirection   cyan
        set -g fish_color_end           yellow
        set -g fish_color_error         red
        set -g fish_color_comment       brblack
        set -g fish_color_autosuggestion brblack
        set -g fish_pager_color_prefix  magenta
        set -g fish_pager_color_completion normal
        set -g fish_pager_color_description brblack
      '';
    };

    home.sessionVariables = {
      EDITOR = "zeditor";
      VISUAL = "zeditor";
    };
  };
}

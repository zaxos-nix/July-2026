{ ... }: {
  # mangowm's own default keybinds (confirmed from the project wiki):
  #   Alt+Return   spawn foot            Alt+Space  spawn rofi
  #   Alt+Q        killclient            Super+M    quit
  #   Super+F      togglefullscreen      Alt+Arrows focus movement
  #   Ctrl+1-9     switch tag            Alt+1-9    move window to tag
  #
  # Rather than re-typing all of those (and risking getting an action
  # keyword slightly wrong), this file `source`s mango's own shipped
  # config at /etc/mango/config.conf — the exact file the project
  # itself documents as "a fallback configuration... you can use this
  # as a reference" — and then layers only the specified overrides on
  # top. mango parses config files top-to-bottom, later binds to the
  # same key win, the same idiom the mango wiki itself shows for
  # splitting config across files with `source=`.
  #
  # This is a real per-user dotfile, which is exactly what home-manager
  # is for — unlike niri (fully baked into the Nix store via
  # wrapper-modules) or DMS (skips `dms setup` entirely), mango has no
  # equivalent declarative path, so this is the one place in the repo
  # where a live config file is the correct tool.
  flake.homeModules.mangoKeybinds = { ... }: {
    xdg.configFile."mango/config.conf".text = ''
      source=/etc/mango/config.conf

      # --- Fix: DMS never appears after picking Mango in dms-greeter ---
      # Mango DOES import the session environment into systemd on its
      # own (confirmed in mango's src/mango.c, set_activation_env():
      # it runs `dbus-update-activation-environment` and
      # `systemctl --user import-environment` automatically at
      # startup) — but that's as far as it goes. It never issues
      # `systemctl --user start graphical-session.target`. dms.service
      # (programs.dms-shell.systemd, dms.nix) is `wantedBy =
      # ["graphical-session.target"]`, so without something starting
      # that target, DMS's bar/launcher/polkit-agent never fire: Mango
      # itself comes up fine (blank screen, ALT+Return still spawns a
      # terminal per mango's own default binds), but none of the shell
      # is there — which is exactly "not working" after authenticating
      # in the greeter. Niri doesn't have this gap; it starts
      # graphical-session.target itself, which is why the same DMS
      # setup "just works" there. Starting it explicitly here closes
      # the gap for Mango too.
      # --- Update: a single unconditional call wasn't enough ---
      # This still races mango's own set_activation_env(): if
      # `start graphical-session.target` fires before WAYLAND_DISPLAY
      # (and friends) have actually landed in the user's systemd
      # instance, dms.service starts against an incomplete
      # environment, can't bind to the compositor, exits, and — since
      # it has no Restart= of its own — just stays dead. Net effect:
      # blank desktop, no DMS, the exact original symptom, even
      # though this line did run. Poll for WAYLAND_DISPLAY actually
      # being importable before starting the target, instead of
      # assuming it's ready the instant this exec-once fires. Capped
      # at 5s so a genuine failure doesn't hang startup indefinitely.
      exec-once=sh -c 'for i in $(seq 1 50); do systemctl --user show-environment | grep -q ^WAYLAND_DISPLAY= && break; sleep 0.1; done; systemctl --user start graphical-session.target'

      # --- Overrides: same targets as niri.nix's custom binds ---
      bind=ALT,Return,spawn,ghostty
      bind=ALT,Space,spawn,dms ipc call spotlight toggle

      # --- Additions: new binds, no default conflict ---
      bind=ALT,n,spawn,nautilus
      bind=ALT,b,spawn,brave
      bind=ALT,comma,spawn,dms ipc call settings toggle
      bind=ALT,v,spawn,dms ipc call clipboard toggle
    '';
  };
}

{ ... }: {
  # ════════════════════════════════════════════════════════════════
  # DankMaterialShell is native in nixpkgs 26.05+ — no flake input, no
  # home-manager. `programs.dms-shell` is a real system-wide NixOS
  # module, same shape as `programs.niri`. This replaces
  # noctalia.nix / noctalia.json entirely (removed).
  #
  # Deliberately NOT running `dms setup`: that command generates/
  # overwrites ~/.config/niri/dms/*.kdl at runtime, which only works if
  # niri's config lives in a writable location. This repo's niri.nix
  # bakes the entire niri config into the Nix store via wrapper-modules,
  # so there is no writable config for `dms setup` to write into — it
  # would silently fail or get reverted on every rebuild. Instead, the
  # handful of DMS IPC binds (Spotlight search, settings, clipboard)
  # are wired directly into niri.nix's `binds`, the same way this repo
  # previously wired Noctalia's launcher.
  # ════════════════════════════════════════════════════════════════
  flake.nixosModules.dmsShell = { ... }: {
    programs.dms-shell = {
      enable = true;

      systemd = {
        enable = true; # DMS starts itself as a user service — no
                        # spawn-at-startup entry needed in niri.nix.
        restartIfChanged = true;
      };

      # Feature toggles, explicit and minimal — each pulls its own
      # dependency set (dgop, matugen, cava, khal, etc.).
      enableSystemMonitoring = true;   # dgop widgets (CPU/RAM/disk)
      enableDynamicTheming = true;     # matugen — GTK/Qt/terminal theming
      enableAudioWavelength = false;   # cava visualizer — not requested
      enableCalendarEvents = false;    # khal integration — not requested
      enableVPN = false;               # VPN widget — not requested

      # DMS ships its own polkit agent (per its own docs: it replaces
      # "waybar, swaylock, swayidle, mako, fuzzel, polkit, and
      # everything else"). lxqt-policykit was dropped from
      # environment.systemPackages (configuration.nix) so only one
      # polkit agent ever registers on the session bus.
    };
  };
}

{ self, inputs, ... }: {
  flake.nixosModules.homeManager = { ... }: {
    imports = [ inputs.home-manager.nixosModules.home-manager ];

    home-manager = {
      useGlobalPkgs = true;   # share the system pkgs eval, don't
                               # duplicate a second nixpkgs instantiation
      useUserPackages = true;
      backupFileExtension = "hm-backup";

      users."izo" = {
        imports = [
          self.homeModules.fishShell
          self.homeModules.starshipPrompt
          self.homeModules.mangoKeybinds

          # Installs Uos, Kora, Tela, and Newaita-reborn icon sets
          # (plus librsvg) and sets Kora as the active gtk.iconTheme,
          # with Adwaita as the default GTK widget theme.
          self.homeModules.iconThemes

          self.homeModules.darkTheme
          self.homeModules.ghosttyConfig
        ];

        home.username = "izo";
        home.homeDirectory = "/home/izo";

        # Must track system.stateVersion in configuration.nix. Bump
        # both together, never independently.
        home.stateVersion = "26.05";

        # Fish/Starship/mango dotfiles are managed by the imports
        # above. niri, DMS, and the greeter stay plain NixOS modules —
        # this doesn't migrate them, see README.
        home.packages = [ ];
      };
    };
  };
}

{ lib, ... }: {
  # flake.nixosModules is a recognized flake-parts output attribute
  # out of the box, which is why niri.nix / dms.nix / mango.nix etc.
  # can each add to it from separate files without conflict.
  # flake.homeModules isn't a standard one, so without this it's just
  # an arbitrary flake output attribute — flake-parts has no idea it's
  # supposed to merge attrsets from multiple files, and the second
  # file to define it clobbers the first. Declaring the option here is
  # what fish.nix / starship.nix / mango-keybinds.nix / icon-theme.nix
  # each defining flake.homeModules.<name> actually needs to work.
  options.flake.homeModules = lib.mkOption {
    type = lib.types.lazyAttrsOf lib.types.unspecified;
    default = { };
  };

  config = {
    systems = [
      "x86_64-linux"
      "x86_64-darwin"
      "aarch64-linux"
      "aarch64-darwin"
    ];
  };
}
